import time, requests, configparser
import win32evtlog  # Requires pywin32

def read_windows_logs():
    server = 'localhost'
    log_type = 'Security'
    logs = []
    handle = win32evtlog.OpenEventLog(server, log_type)
    total = win32evtlog.GetNumberOfEventLogRecords(handle)
    events = win32evtlog.ReadEventLog(handle, win32evtlog.EVENTLOG_BACKWARDS_READ|win32evtlog.EVENTLOG_SEQUENTIAL_READ, 0)
    for event in events[:20]:  # Limit for testing
        logs.append(f"{event.TimeGenerated} {event.SourceName} {event.EventID}")
    return "\n".join(logs)

def send_logs():
    config = configparser.ConfigParser()
    config.read('config.ini')
    url = config['agent']['server_url']

    while True:
        try:
            logs = read_windows_logs()
            requests.post(url, json={"os": "Windows", "logs": logs})
        except Exception as e:
            print("Error:", e)
        time.sleep(int(config['agent']['interval']))

if __name__ == "__main__":
    send_logs()
