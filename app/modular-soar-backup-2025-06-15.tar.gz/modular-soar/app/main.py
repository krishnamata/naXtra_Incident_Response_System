from flask import Flask
from dashboard.routes import dashboard_bp, config_bp  # import both from routes.py

app = Flask(__name__)
app.register_blueprint(dashboard_bp)
app.register_blueprint(config_bp)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

