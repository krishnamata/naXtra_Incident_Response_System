from flask import Blueprint, render_template, request, redirect, url_for, flash
import json
import os

dashboard_bp = Blueprint('dashboard', __name__, template_folder='templates')

LOG_FILES = {
    'Auth Log': '/app/logs/auth.log',
    'Boot Log': '/app/logs/boot.log',
    'DPKG Log': '/app/logs/dpkg.log',
}

@dashboard_bp.route('/')
def dashboard():
    logs = {}
    for name, path in LOG_FILES.items():
        try:
            with open(path, 'r') as f:
                logs[name] = f.read()
        except Exception as e:
            logs[name] = f"Error reading {path}: {str(e)}"
    return render_template('dashboard.html', logs=logs)

config_bp = Blueprint('config', __name__, template_folder='templates')

CONFIG_FILE = 'log_sources.json'

DEFAULT_SOURCES = {
    "local": {
        "Auth Log": "/app/logs/auth.log",
        "Boot Log": "/app/logs/boot.log",
        "DPKG Log": "/app/logs/dpkg.log"
    }
}

def load_config():
    if not os.path.exists(CONFIG_FILE):
        save_config(DEFAULT_SOURCES)
        return DEFAULT_SOURCES

    with open(CONFIG_FILE, 'r') as f:
        data = json.load(f)

    # Add missing defaults if not present
    for src, logs in DEFAULT_SOURCES.items():
        if src not in data:
            data[src] = logs
        else:
            for key, path in logs.items():
                if key not in data[src]:
                    data[src][key] = path

    save_config(data)
    return data

def save_config(data):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(data, f, indent=4)

@config_bp.route('/config', methods=['GET', 'POST'])
def config():
    config_data = load_config()

    if request.method == 'POST':
        source_name = request.form.get('source_name')
        log_key = request.form.get('log_key')
        log_path = request.form.get('log_path')

        if source_name and log_key and log_path:
            if source_name not in config_data:
                config_data[source_name] = {}
            config_data[source_name][log_key] = log_path
            save_config(config_data)
            flash('Log source updated successfully!', 'success')
        else:
            flash('Please fill all fields.', 'danger')
        return redirect(url_for('config.config'))

    return render_template('config.html', config=config_data)

@config_bp.route('/config/delete', methods=['POST'])
def delete_entry():
    source_name = request.form.get('source')
    log_key = request.form.get('log')
    config_data = load_config()

    if source_name in config_data and log_key in config_data[source_name]:
        del config_data[source_name][log_key]
        if not config_data[source_name]:
            del config_data[source_name]
        save_config(config_data)
        flash('Log entry deleted.', 'info')

    return redirect(url_for('config.config'))

